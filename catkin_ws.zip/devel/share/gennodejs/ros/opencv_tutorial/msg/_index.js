
"use strict";

let msgTutorial = require('./msgTutorial.js');

module.exports = {
  msgTutorial: msgTutorial,
};
